Date : 07/28/10 

ion Design Inc.
4410 Shoalwood
Austin, Texas  78756          
                        
Design Manager    : Darren Larson
                  : (512)260-5778
             Email: dlarson@iondsn.com
        Cell Phone: (512)630-9814

Designer Contact  : Hector A.
                  : (512)260-5778
            Email : hectora@iondsn.com

Job#  100208CTC1A

README for ctc063_nologo_gerbers.zip

Files contained in the zip file:

README.1st      This file
ctclyr1.063   	Layer 1
ctclyr2.063     Layer 2
ctclyr3.063   	Layer 3
ctclyr4.063     Layer 4
ctclyr5.063   	Layer 5
ctclyr6.063     Layer 6
ctcsmc.063   	Soldermask Layer 1 Side (Component)
ctcsms.063    	Soldermask Layer 6 Side (Solder)
ctcspc.063    	Solder Paste Layer 1 Side (for Assembly ONLY)(Ref.ONLY)
ctcsps.063    	Solder Paste Layer 6 Side (for Assembly ONLY)(Ref.ONLY)
ctctslk.063 	Silk Screen Layer 1 side
ctcbslk.063 	Silk Screen Layer 6 side
ctcfab1.063    	Fabrication Drawing Page 1(for Ref. ONLY)
ctcfab2.063 	Fabrication Drawing Page 2)for Ref. ONLY)
ctcassy1.063     Assembly Drawing Page 1 (for Ref. ONLY)
ctcassy2.063    Assembly Drawing Page 2 (for Ref. ONLY)
ncdrill1-2.drl   	Drill tape, Layer 1 through 2
ncdrill1-3.drl		Drill tape, Layer 1 through 3
ncdrill1-6.drl		Drill tape, through
nc_param.txt 	Drill tape setup file
ncdrill.log    	Drill tape composite file (for Reference ONLY)
ctc063.ipc     	IPC-D-356 netlist (for Checking ONLY)
art_param.txt  	Artwork Format File (for Ref. ONLY)
ctccen.063	Placement file for Assembly (for Ref. Only)
ctcnet.063 	Allegro Netlist (for Ref. Only)

Notes:	PLEASE REVIEW FAB DRAWING FOR SPECIFIC REQUIREMENTS.

