namespace Accelerometer_full
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.label16 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.axis3SensitivityScrl = new System.Windows.Forms.TrackBar();
            this.axis2SensitivityScrl = new System.Windows.Forms.TrackBar();
            this.axis1SensitivityScrl = new System.Windows.Forms.TrackBar();
            this.label9 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.label12 = new System.Windows.Forms.Label();
            this.rangeTxt = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.axesTxt = new System.Windows.Forms.TextBox();
            this.versionTxt = new System.Windows.Forms.TextBox();
            this.serialTxt = new System.Windows.Forms.TextBox();
            this.nameTxt = new System.Windows.Forms.TextBox();
            this.attachedTxt = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.axis3AccelTxt = new System.Windows.Forms.TextBox();
            this.axis2AccelTxt = new System.Windows.Forms.TextBox();
            this.axis1AccelTxt = new System.Windows.Forms.TextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.groupBox3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.axis3SensitivityScrl)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.axis2SensitivityScrl)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.axis1SensitivityScrl)).BeginInit();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.label16);
            this.groupBox3.Controls.Add(this.label15);
            this.groupBox3.Controls.Add(this.label14);
            this.groupBox3.Controls.Add(this.axis3SensitivityScrl);
            this.groupBox3.Controls.Add(this.axis2SensitivityScrl);
            this.groupBox3.Controls.Add(this.axis1SensitivityScrl);
            this.groupBox3.Controls.Add(this.label9);
            this.groupBox3.Controls.Add(this.label8);
            this.groupBox3.Controls.Add(this.label6);
            this.groupBox3.Location = new System.Drawing.Point(12, 217);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(231, 173);
            this.groupBox3.TabIndex = 4;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Sensitivity Settings";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(10, 128);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(41, 13);
            this.label16.TabIndex = 7;
            this.label16.Text = "label16";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(10, 80);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(41, 13);
            this.label15.TabIndex = 6;
            this.label15.Text = "label15";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(10, 32);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(41, 13);
            this.label14.TabIndex = 0;
            this.label14.Text = "label14";
            // 
            // axis3SensitivityScrl
            // 
            this.axis3SensitivityScrl.Location = new System.Drawing.Point(72, 115);
            this.axis3SensitivityScrl.Name = "axis3SensitivityScrl";
            this.axis3SensitivityScrl.Size = new System.Drawing.Size(149, 42);
            this.axis3SensitivityScrl.TabIndex = 5;
            this.axis3SensitivityScrl.TickStyle = System.Windows.Forms.TickStyle.None;
            this.axis3SensitivityScrl.Scroll += new System.EventHandler(this.axis3SensitivityScrl_Scroll);
            // 
            // axis2SensitivityScrl
            // 
            this.axis2SensitivityScrl.Location = new System.Drawing.Point(72, 67);
            this.axis2SensitivityScrl.Name = "axis2SensitivityScrl";
            this.axis2SensitivityScrl.Size = new System.Drawing.Size(149, 42);
            this.axis2SensitivityScrl.TabIndex = 4;
            this.axis2SensitivityScrl.TickStyle = System.Windows.Forms.TickStyle.None;
            this.axis2SensitivityScrl.Scroll += new System.EventHandler(this.axis2SensitivityScrl_Scroll);
            // 
            // axis1SensitivityScrl
            // 
            this.axis1SensitivityScrl.Location = new System.Drawing.Point(72, 19);
            this.axis1SensitivityScrl.Name = "axis1SensitivityScrl";
            this.axis1SensitivityScrl.Size = new System.Drawing.Size(149, 42);
            this.axis1SensitivityScrl.TabIndex = 0;
            this.axis1SensitivityScrl.TickStyle = System.Windows.Forms.TickStyle.None;
            this.axis1SensitivityScrl.Scroll += new System.EventHandler(this.axis1SensitivityScrl_Scroll);
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(10, 115);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(38, 13);
            this.label9.TabIndex = 3;
            this.label9.Text = "Axis 3:";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(10, 67);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(38, 13);
            this.label8.TabIndex = 2;
            this.label8.Text = "Axis 2:";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(10, 19);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(38, 13);
            this.label6.TabIndex = 0;
            this.label6.Text = "Axis 1:";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.label12);
            this.groupBox1.Controls.Add(this.rangeTxt);
            this.groupBox1.Controls.Add(this.label5);
            this.groupBox1.Controls.Add(this.axesTxt);
            this.groupBox1.Controls.Add(this.versionTxt);
            this.groupBox1.Controls.Add(this.serialTxt);
            this.groupBox1.Controls.Add(this.nameTxt);
            this.groupBox1.Controls.Add(this.attachedTxt);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.groupBox1.Location = new System.Drawing.Point(12, 12);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(231, 199);
            this.groupBox1.TabIndex = 2;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Accelerometer Info";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(13, 171);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(42, 13);
            this.label12.TabIndex = 11;
            this.label12.Text = "Range:";
            // 
            // rangeTxt
            // 
            this.rangeTxt.Location = new System.Drawing.Point(72, 168);
            this.rangeTxt.Name = "rangeTxt";
            this.rangeTxt.ReadOnly = true;
            this.rangeTxt.Size = new System.Drawing.Size(149, 20);
            this.rangeTxt.TabIndex = 10;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(13, 145);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(33, 13);
            this.label5.TabIndex = 9;
            this.label5.Text = "Axes:";
            // 
            // axesTxt
            // 
            this.axesTxt.Location = new System.Drawing.Point(72, 142);
            this.axesTxt.Name = "axesTxt";
            this.axesTxt.ReadOnly = true;
            this.axesTxt.Size = new System.Drawing.Size(149, 20);
            this.axesTxt.TabIndex = 8;
            // 
            // versionTxt
            // 
            this.versionTxt.Location = new System.Drawing.Point(72, 116);
            this.versionTxt.Name = "versionTxt";
            this.versionTxt.ReadOnly = true;
            this.versionTxt.Size = new System.Drawing.Size(149, 20);
            this.versionTxt.TabIndex = 7;
            // 
            // serialTxt
            // 
            this.serialTxt.Location = new System.Drawing.Point(72, 90);
            this.serialTxt.Name = "serialTxt";
            this.serialTxt.ReadOnly = true;
            this.serialTxt.Size = new System.Drawing.Size(149, 20);
            this.serialTxt.TabIndex = 6;
            // 
            // nameTxt
            // 
            this.nameTxt.Location = new System.Drawing.Point(72, 45);
            this.nameTxt.Multiline = true;
            this.nameTxt.Name = "nameTxt";
            this.nameTxt.ReadOnly = true;
            this.nameTxt.Size = new System.Drawing.Size(149, 39);
            this.nameTxt.TabIndex = 5;
            // 
            // attachedTxt
            // 
            this.attachedTxt.Location = new System.Drawing.Point(72, 19);
            this.attachedTxt.Name = "attachedTxt";
            this.attachedTxt.ReadOnly = true;
            this.attachedTxt.Size = new System.Drawing.Size(149, 20);
            this.attachedTxt.TabIndex = 4;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(13, 119);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(45, 13);
            this.label4.TabIndex = 3;
            this.label4.Text = "Version:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(10, 93);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(56, 13);
            this.label3.TabIndex = 2;
            this.label3.Text = "Serial No.:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(13, 48);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(38, 13);
            this.label2.TabIndex = 1;
            this.label2.Text = "Name:";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(13, 22);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(53, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Attached:";
            // 
            // panel1
            // 
            this.panel1.Location = new System.Drawing.Point(249, 47);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(317, 317);
            this.panel1.TabIndex = 5;
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.axis3AccelTxt);
            this.groupBox2.Controls.Add(this.axis2AccelTxt);
            this.groupBox2.Controls.Add(this.axis1AccelTxt);
            this.groupBox2.Controls.Add(this.label11);
            this.groupBox2.Controls.Add(this.label10);
            this.groupBox2.Controls.Add(this.label7);
            this.groupBox2.Location = new System.Drawing.Point(12, 396);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(554, 69);
            this.groupBox2.TabIndex = 6;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Acceleration Data";
            // 
            // axis3AccelTxt
            // 
            this.axis3AccelTxt.Location = new System.Drawing.Point(416, 28);
            this.axis3AccelTxt.Name = "axis3AccelTxt";
            this.axis3AccelTxt.ReadOnly = true;
            this.axis3AccelTxt.Size = new System.Drawing.Size(132, 20);
            this.axis3AccelTxt.TabIndex = 13;
            // 
            // axis2AccelTxt
            // 
            this.axis2AccelTxt.Location = new System.Drawing.Point(237, 28);
            this.axis2AccelTxt.Name = "axis2AccelTxt";
            this.axis2AccelTxt.ReadOnly = true;
            this.axis2AccelTxt.Size = new System.Drawing.Size(132, 20);
            this.axis2AccelTxt.TabIndex = 12;
            // 
            // axis1AccelTxt
            // 
            this.axis1AccelTxt.Location = new System.Drawing.Point(55, 28);
            this.axis1AccelTxt.Name = "axis1AccelTxt";
            this.axis1AccelTxt.ReadOnly = true;
            this.axis1AccelTxt.Size = new System.Drawing.Size(132, 20);
            this.axis1AccelTxt.TabIndex = 11;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(375, 31);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(38, 13);
            this.label11.TabIndex = 2;
            this.label11.Text = "Axis 3:";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(193, 31);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(38, 13);
            this.label10.TabIndex = 1;
            this.label10.Text = "Axis 2:";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(11, 31);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(38, 13);
            this.label7.TabIndex = 0;
            this.label7.Text = "Axis 1:";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(249, 31);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(74, 13);
            this.label13.TabIndex = 7;
            this.label13.Text = "Motion Graph:";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(580, 478);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.groupBox1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximumSize = new System.Drawing.Size(588, 505);
            this.MinimumSize = new System.Drawing.Size(588, 505);
            this.Name = "Form1";
            this.Text = "Accelerometer - full";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.Form1_FormClosing);
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.axis3SensitivityScrl)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.axis2SensitivityScrl)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.axis1SensitivityScrl)).EndInit();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox axesTxt;
        private System.Windows.Forms.TextBox versionTxt;
        private System.Windows.Forms.TextBox serialTxt;
        private System.Windows.Forms.TextBox nameTxt;
        private System.Windows.Forms.TextBox attachedTxt;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.TextBox rangeTxt;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.TextBox axis3AccelTxt;
        private System.Windows.Forms.TextBox axis2AccelTxt;
        private System.Windows.Forms.TextBox axis1AccelTxt;
        private System.Windows.Forms.TrackBar axis3SensitivityScrl;
        private System.Windows.Forms.TrackBar axis2SensitivityScrl;
        private System.Windows.Forms.TrackBar axis1SensitivityScrl;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label14;

    }
}

