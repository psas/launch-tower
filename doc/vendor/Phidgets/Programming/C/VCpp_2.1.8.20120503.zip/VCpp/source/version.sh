#!/bin/bash

library_version="2.1.8"
date=$( date +%Y%m%d )

echo -n "$library_version.$date"