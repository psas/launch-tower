Microsoft Visual Studio C Examples for Phidget21.

It is assumed that the Phidgets Framework is installed into "$(SystemDrive)\Program Files\Phidgets". 
If the Phidgets Framework is installed into a different directory, the project settings will need to be modified. 
Please see the "Setting up a Phidgets Project" in the Getting Started Guide for Visual Studio C/C++ for more information. 